import request from "@/utils/request";

// 登录
export async function login(){
  return request.post({

  })
}
// 登出
export async function logout(){
  return request.post({
    
  })
}
// 获取用户信息
export async function getInfo(){
  return request.post({
    
  })
}