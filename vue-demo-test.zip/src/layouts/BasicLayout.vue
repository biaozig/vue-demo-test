<template>
  <div class="basic-layout">
    <router-view/>
  </div>
</template>

<style lang="less">

</style>
