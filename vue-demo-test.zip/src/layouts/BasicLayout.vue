<template>
  <div class="basic-layout">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'BasicLayout'
  
}
</script>
<style lang="less">

</style>
