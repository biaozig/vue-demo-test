<template>
  <div class="blank-layout">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'BlankLayout'
  
}
</script>
<style lang="less">

</style>
