<template>
  <div class="blank-layout">
    <router-view/>
  </div>
</template>

<style lang="less">

</style>
