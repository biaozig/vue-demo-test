<template>
  <div class="user-layout">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'UserLayout'
  
}
</script>
<style lang="less">

</style>
