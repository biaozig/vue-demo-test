<template>
  <div class="user-layout">
    <router-view/>
  </div>
</template>

<style lang="less">

</style>
