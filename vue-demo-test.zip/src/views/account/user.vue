<template>
  <div class="account">
    <h1>This is an account user page</h1>
  </div>
</template>
