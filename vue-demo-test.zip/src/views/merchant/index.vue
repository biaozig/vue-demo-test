<template>
  <div class="merchant-page">
    <h1>This is an merchant page</h1>
  </div>
</template>
